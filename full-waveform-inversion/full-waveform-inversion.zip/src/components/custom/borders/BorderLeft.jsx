export default function BorderLeft() {
    return (
        <div className={`border-l border-[#D7DFFF]`} />
    )
}