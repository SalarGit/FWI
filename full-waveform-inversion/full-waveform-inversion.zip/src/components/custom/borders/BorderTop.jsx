export default function BorderTop({ className }) {
    return (
        <div className={`border-t border-[#D7DFFF] ${className}`} />
    )
}