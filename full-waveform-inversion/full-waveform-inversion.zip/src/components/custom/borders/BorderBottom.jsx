export default function BorderBottom({ className }) {
    return (
        <div className={`border-b border-[#D7DFFF] ${className}`} />
    )
}