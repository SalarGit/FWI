export default function H1({ heading }) {
    return (
        <p className={`text-lg font-bold`}>{heading}</p>
    )
}