export default function H3({ children }) {
    return (
        <p className={`text-zinc-500 font-medium text-sm`}>{children}</p>
    )
}