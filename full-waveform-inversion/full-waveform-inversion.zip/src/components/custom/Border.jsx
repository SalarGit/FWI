export default function Border() {
    return (
        <div className={`border-solid border-t border-[#D7DFFF]`} />
    )
}