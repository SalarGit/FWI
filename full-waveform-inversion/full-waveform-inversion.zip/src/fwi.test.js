import React, { act } from 'react';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';

import App from './App.jsx';
import Header from './components/header/Header.jsx';
import * as apiService from './api/apiService.js';
import NewRun from './components/header/sections/newrun/NewRun.jsx';
import SessionContextProvider from './store/session-context.jsx'
import { SessionContext } from './store/session-context.jsx';
import JSZip from 'jszip';
import Output from './components/IO/Output.jsx';
import Settings from './components/settings/Settings.jsx';
import HistoryOfRuns from './components/header/sections/historyofruns/HistoryOfRuns.jsx';

jest.mock('./api/apiService.js');

// Mock JSZip behavior
jest.mock('jszip', () => {
    return jest.fn().mockImplementation(() => {
        return {
            loadAsync: jest.fn().mockResolvedValue({
                file: jest.fn(() => ({
                    async: jest.fn().mockResolvedValue(JSON.stringify({
                        ngrid: { x: 10, z: 10 },
                        forward: "ForwardModel",
                        minimization: "MinimizationModel"
                    }))
                })),
            })
        };
    });
});

// Mock the required props for the tests
const mockHistoryLengthZero = 0;
const mockHistoryLengthTwo = 2;

const mockContextValue = {
    addRunToSession: jest.fn(),
    updateSessionRun: jest.fn(),
    handleCurrentRun: jest.fn(),
    addProgressingRun: jest.fn(),
    updateProgressingRun: jest.fn(),
    removeProgressingRun: jest.fn(),
};

describe('load App', () => {
    beforeEach(() => {
        // Mock the fetchHistoryLength function
        apiService.fetchHistoryLength.mockResolvedValue({ success: true, historyLength: 5 });
    });

    test.each([
      /full waveform inversion/i,
      /settings/i,
      /original input/i,
      /calculated output/i
    ])('should display "%s" in the document', async (text) => {
        await act(async () => {
            render(<App />);
        });
        
        await waitFor(() => {
            expect(screen.getByText(text)).toBeInTheDocument();
        }, { timeout: 3000 });
    });
});

describe('history of runs', () => {
    test('should disable the "History of runs" button when historyLength is 0', () => {
        render(<Header historyLength={mockHistoryLengthZero} />);
        
        // Check if the 'History of Runs' button is disabled
        const historyButton = screen.getByText(/history of runs/i);
        expect(historyButton).toBeDisabled();
    });
    test('should enable the History of Runs button when historyLength is > 0', () => {
        render(<Header historyLength={mockHistoryLengthTwo} />);
        
        // Check if the 'History of Runs' button is disabled
        const historyButton = screen.getByText(/history of runs/i);
        expect(historyButton).toHaveAttribute('disabled', '');
    });

    test('should display HistoryOfRuns component when the History of Runs button is clicked', async () => {
        apiService.fetchHistoryLength.mockResolvedValue({ success: true, historyLength: 5 });
        apiService.fetchHistoryOfRuns.mockResolvedValue({ successHistory: true, history: {} });

        await act(async () => {
            render(<App />);
        });
        
        await waitFor(() => {
            const historyButton = screen.getByText(/history of runs/i);
            expect(historyButton).toBeInTheDocument();
        });

        const historyButton = screen.getByText(/history of runs/i);
        fireEvent.click(historyButton);
        
        await waitFor(() => {
            expect(screen.getByText(/download/i)).toBeInTheDocument();
        }, { timeout: 3000 });
    });
})

describe('add new run', () => {
    beforeEach(() => {
        // jest.clearAllMocks();
        apiService.fetchHistoryLength.mockResolvedValue({ success: true, historyLength: 5 });
    });

    test('should display NewRun component when the Add New Run button is clicked', async () => {
        await act(async () => {
            render(<App />);
        });
        
        // Click the 'Add New Run' button
        const newRunButton = screen.getByText(/add new run/i);
        fireEvent.click(newRunButton);
        
        // Verify that the input field for entering the run name appears
        expect(screen.getByPlaceholderText(/enter run name.../i)).toBeInTheDocument();
    });

    // test('should enable the Confirm button when text is entered into the input field', async () => {
    //     // Render the App component
    //     await act(async () => {
    //         render(<App />);
    //     });

    //     // Click the 'Add New Run' button
    //     const newRunButton = screen.getByText(/add new run/i);
    //     fireEvent.click(newRunButton);

    //     // Confirm NewRun has appeared
    //     expect(screen.getByPlaceholderText(/enter run name.../i)).toBeInTheDocument();
    
    //     // Confirm button should be initially disabled
    //     const confirmButton = screen.getByText(/confirm/i);
    //     expect(confirmButton).toBeDisabled();

    //     // Simulate user typing in the input field
    //     const inputField = screen.getByPlaceholderText(/enter run name.../i);
    //     fireEvent.change(inputField, { target: { value: 'New Run' } });

    //     // Now the confirm button should be enabled
    //     await waitFor(() => expect(confirmButton).not.toBeDisabled());
    // });

    test('should enable the Confirm button when text is entered into the input field', () => {    
        // Render the NewRun component
        render(<NewRun />);
    
        // Confirm button should be initially disabled
        const confirmButton = screen.getByText(/confirm/i);
        expect(confirmButton).toBeDisabled();

        // Simulate user typing in the input field
        const inputField = screen.getByPlaceholderText(/enter run name.../i);
        fireEvent.change(inputField, { target: { value: 'New Run' } });

        // Now the confirm button should be enabled
        // await waitFor(() => expect(confirmButton).not.toBeDisabled());
        expect(confirmButton).not.toBeDisabled();
    });

    test('should render specific elements when caseId is [true, "New run"]', async () => {

        // Mock the useState hook for caseId to start as [true, "New run"]
        jest.spyOn(React, 'useState')
        .mockImplementationOnce(() => [null, jest.fn()]) // Mock zipContent as null
        .mockImplementationOnce(() => ['', jest.fn()])   // Mock zipFileName as ''
        .mockImplementationOnce(() => [[true, 'New run'], jest.fn()]) // Mock caseId as [true, "New run"]
    
        render(
            // <SessionContext.Provider value={mockContextValue}>
                <NewRun />
            // </SessionContext.Provider>
        );

        // Assert that the elements inside the {caseId[0] && ...} block are present
        expect(screen.getByPlaceholderText('Select a folder...')).toBeInTheDocument();
        // expect(screen.getByText(/download/i)).toBeInTheDocument();
        // expect(screen.getByText(/Grid size:/i)).toBeInTheDocument();
        // expect(screen.getByText(/Subsurface model:/i)).toBeInTheDocument();
    });

    // test('should render entire add new run form when caseId is chosen & zip is selected', async () => {
    //     // Mock the useState hook for caseId to start as [true, "New run"]
    //     jest.spyOn(React, 'useState')
    //     .mockImplementationOnce(() => [null, jest.fn()])  // zipContent
    //     .mockImplementationOnce(() => ['', jest.fn()])    // zipFileName
    //     .mockImplementationOnce(() => [[true, 'New run'], jest.fn()])  // caseId
    //     .mockImplementationOnce(() => [[], jest.fn()])    // minimizationModels
    //     .mockImplementationOnce(() => [[], jest.fn()])    // forwardModels
    //     .mockImplementationOnce(() => [{}, jest.fn()])    // selectedModels
    //     .mockImplementationOnce(() => [{}, jest.fn()])    // genericInput
    //     .mockImplementationOnce(() => [false, jest.fn()]);  // isZipProcessed
    
    //     // Render the NewRun component
    //     render(<NewRun onClose={jest.fn()} encodeSpaces={jest.fn()} />);

    //     // Simulate file upload
    //     const file = new File(['dummy content'], 'dummy.zip', { type: 'application/zip' });
        
    //     // Find the hidden input field by its id "caseFolder"
    //     const fileInput = screen.getByLabelText(/select folder/i);  // Select folder label
        
    //     // Fire the change event to simulate file upload
    //     fireEvent.change(fileInput, { target: { files: [file] } });

    //     // Wait for the handleZipChange logic to execute
    //     await waitFor(() => {
    //         // Ensure the zip file name is displayed after upload
    //         expect(screen.getByDisplayValue('dummy.zip')).toBeInTheDocument();
    //     });

    //     // const calculateButton = screen.getByText(/calculate/i);
    //     // expect(calculateButton ).toBeInTheDocument();
    // });

});

describe('calculated output', () => {
    test('should switch output type when new output type has been selected', async () => {
        await act(async () => {
            render(<App />)
        });
        
        // expect(screen.getByText(/output values/i)).toBeInTheDocument();

        // Ensure the "Output values" button is in the document
        const outputValuesButton = screen.getByText(/output values/i);
        expect(outputValuesButton).toBeInTheDocument();

        // Click the button to open the dropdown
        fireEvent.click(outputValuesButton);

        // Ensure the dropdown items are present
        const residualFieldOption = screen.getByText(/residual field/i);
        expect(residualFieldOption).toBeInTheDocument();

        // Select an item from the dropdown (e.g., "Residual field")
        fireEvent.click(residualFieldOption);

        // Verify that the button's text has changed to the selected item
        expect(screen.getByText(/residual field/i)).toBeInTheDocument();
    });

});

describe('HistoryOfRuns component', () => {
    test('should enable output buttons when a run is selected', async () => {
        // Mock the session context with a historyOfRuns object containing a single run
        const mockContextValue = {
            historyOfRuns: {
                'Run 1': {
                    ngrid: { x: 100, z: 100 },
                    forward: 'ForwardModel1',
                    minimization: 'MinimizationModel1',
                    threads: 4,
                    caseFolder: 'Folder1'
                }
            },
            updateHistoryOfRuns: jest.fn()
        };

        // Render the HistoryOfRuns component within the mocked SessionContext
        render(
            <SessionContext.Provider value={mockContextValue}>
                <HistoryOfRuns onClose={jest.fn()} />
            </SessionContext.Provider>
        );

        // Ensure the run is displayed in the table
        expect(screen.getByText(/Run 1/i)).toBeInTheDocument();

        // Get all checkboxes and select the first one
        const checkboxes = screen.getAllByRole('checkbox');
        fireEvent.click(checkboxes[0]);

        // After selecting the run, the output type buttons should be enabled
        const residualFieldButton = screen.getByText(/Residual field/i);
        const residualGraphButton = screen.getByText(/Residual graph/i);
        const qualityMetricsButton = screen.getByText(/Quality metrics/i);

        // Check if the buttons are no longer disabled
        expect(residualFieldButton).not.toBeDisabled();
        expect(residualGraphButton).not.toBeDisabled();
        expect(qualityMetricsButton).not.toBeDisabled();
    });
});

// describe('settings', () => {
//     test('should show current run settings when a run is processing', async () => {
//         const mockSessionRuns = {
//             "Bruh": {
//                 // forwardModel: "ForwardModel1",
//                 // minimizationModel: "MinimizationModel1",
//                 // forwardData: { field1: "value1", field2: "value2" },  // mock forwardData object
//                 // minimizationData: { field3: "value3", field4: "value4" },  // mock minimizationData object
//                 // processingSteps: ['Pre-processing', 'Processing', 'Post-processing'],  // example processing steps
//                 // threads: 4,  // mock number of threads
//                 // processed: true  // indicate the run is still processing
//             }
//         };

//         await act(async () => {
//             render(<Settings currentRun='Bruh' sessionRuns={mockSessionRuns} />)
//         });

//         // Check if the current run settings (New run) are rendered
//         await waitFor(() => {
//             expect(screen.getByText(/bruh/i)).toBeInTheDocument()

//         }, { timeout: 3000 });
        
//     });
// });